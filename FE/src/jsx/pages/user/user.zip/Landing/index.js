export { default } from './Landing';

